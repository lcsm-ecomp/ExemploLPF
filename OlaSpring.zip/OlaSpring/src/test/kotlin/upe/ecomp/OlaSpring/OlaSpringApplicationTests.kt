package upe.ecomp.OlaSpring

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class OlaSpringApplicationTests {

	@Test
	fun contextLoads() {
	}

}
